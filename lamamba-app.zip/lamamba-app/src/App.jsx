import { useState, useEffect } from "react";

// ─── CREDENCIALES ────────────────────────────────────────────────────────────
const USERS = [
  { id: 1, user: "admin", pass: "admin123", role: "admin", name: "Administrador" },
  { id: 2, user: "empleado1", pass: "emp123", role: "empleado", name: "Empleado 1" },
  { id: 3, user: "empleado2", pass: "emp456", role: "empleado", name: "Empleado 2" },
];

const INITIAL_PRODUCTS = [
  { id: 1, name: "OG Kush", category: "Flor", price: 8, stock: 200, thc: "22%", img: "🌿" },
  { id: 2, name: "White Widow", category: "Flor", price: 7, stock: 150, thc: "19%", img: "🌱" },
  { id: 3, name: "Hash Pollen", category: "Hash", price: 10, stock: 80, thc: "35%", img: "🟫" },
  { id: 4, name: "Amnesia Haze", category: "Flor", price: 9, stock: 120, thc: "25%", img: "🍃" },
];

const INITIAL_MEMBERS = [
  { id: 1, name: "Carlos Martínez", dni: "12345678A", email: "carlos@mail.com", phone: "612345678", balance: 50, joinDate: "15/01/2024", active: true, notes: "" },
  { id: 2, name: "Laura Gómez", dni: "87654321B", email: "laura@mail.com", phone: "698765432", balance: 120, joinDate: "22/03/2024", active: true, notes: "" },
];

const load = (key, fallback) => { try { const v = localStorage.getItem(key); return v ? JSON.parse(v) : fallback; } catch { return fallback; } };
const save = (key, val) => { try { localStorage.setItem(key, JSON.stringify(val)); } catch {} };

const Icon = ({ d, size = 20 }) => (
  <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
    <path d={d} />
  </svg>
);
const Icons = {
  home: "M3 9l9-7 9 7v11a2 2 0 01-2 2H5a2 2 0 01-2-2z M9 22V12h6v10",
  users: "M17 21v-2a4 4 0 00-4-4H5a4 4 0 00-4 4v2 M23 21v-2a4 4 0 00-3-3.87 M16 3.13a4 4 0 010 7.75",
  box: "M21 16V8a2 2 0 00-1-1.73l-7-4a2 2 0 00-2 0l-7 4A2 2 0 003 8v8a2 2 0 001 1.73l7 4a2 2 0 002 0l7-4A2 2 0 0021 16z",
  cart: "M6 2L3 6v14a2 2 0 002 2h14a2 2 0 002-2V6l-3-4z M3 6h18 M16 10a4 4 0 01-8 0",
  logout: "M9 21H5a2 2 0 01-2-2V5a2 2 0 012-2h4 M16 17l5-5-5-5 M21 12H9",
  plus: "M12 5v14 M5 12h14",
  trash: "M3 6h18 M19 6v14a2 2 0 01-2 2H7a2 2 0 01-2-2V6m3 0V4a1 1 0 011-1h4a1 1 0 011 1v2",
  history: "M12 2a10 10 0 100 20A10 10 0 0012 2z M12 6v6l4 2",
  edit: "M11 4H4a2 2 0 00-2 2v14a2 2 0 002 2h14a2 2 0 002-2v-7 M18.5 2.5a2.121 2.121 0 013 3L12 15l-4 1 1-4 9.5-9.5z",
  eye: "M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z M12 9a3 3 0 100 6 3 3 0 000-6z",
  wallet: "M21 12V7H5a2 2 0 010-4h14v4 M3 5v14a2 2 0 002 2h16v-5 M18 12a2 2 0 000 4h3v-4z",
  staff: "M20 21v-2a4 4 0 00-4-4H8a4 4 0 00-4 4v2 M12 3a4 4 0 100 8 4 4 0 000-8z",
};

// ─── APP PRINCIPAL ───────────────────────────────────────────────────────────
export default function App() {
  const [session, setSession] = useState(null);
  const [products, setProducts] = useState(() => load("mb_products", INITIAL_PRODUCTS));
  const [members, setMembers] = useState(() => load("mb_members", INITIAL_MEMBERS));
  const [transactions, setTransactions] = useState(() => load("mb_tx", []));

  useEffect(() => { save("mb_products", products); }, [products]);
  useEffect(() => { save("mb_members", members); }, [members]);
  useEffect(() => { save("mb_tx", transactions); }, [transactions]);

  const addTx = (tx) => setTransactions(prev => [{ ...tx, id: Date.now(), date: new Date().toLocaleString("es-ES") }, ...prev]);

  if (!session) return <LoginScreen onLogin={setSession} />;
  return (
    <MainPanel
      session={session}
      products={products} setProducts={setProducts}
      members={members} setMembers={setMembers}
      transactions={transactions} addTx={addTx}
      onLogout={() => setSession(null)}
    />
  );
}

// ─── LOGIN ────────────────────────────────────────────────────────────────────
function LoginScreen({ onLogin }) {
  const [user, setUser] = useState("");
  const [pass, setPass] = useState("");
  const [error, setError] = useState("");

  const handleLogin = () => {
    const found = USERS.find(u => u.user === user && u.pass === pass);
    if (found) onLogin(found);
    else setError("Usuario o contraseña incorrectos");
  };

  return (
    <div style={S.loginBg}>
      <div style={S.loginCard}>
        <div style={S.loginLogo}>
          <span style={{ fontSize: 52 }}>🐍</span>
          <h1 style={S.loginTitle}>La Mamba Negra</h1>
          <p style={S.loginSub}>Asociación Cannábica Privada</p>
        </div>
        {error && <div style={S.errorBox}>{error}</div>}
        <div style={S.formGroup}>
          <input placeholder="Usuario" value={user} onChange={e => { setUser(e.target.value); setError(""); }} style={S.input} />
          <input placeholder="Contraseña" type="password" value={pass} onChange={e => { setPass(e.target.value); setError(""); }} style={S.input} onKeyDown={e => e.key === "Enter" && handleLogin()} />
          <button onClick={handleLogin} style={S.btnPrimary}>Acceder</button>
        </div>
        <p style={{ color: "#475569", fontSize: 11, textAlign: "center", marginTop: 20, letterSpacing: 1 }}>ACCESO SOLO PARA PERSONAL AUTORIZADO</p>
      </div>
    </div>
  );
}

// ─── PANEL PRINCIPAL ──────────────────────────────────────────────────────────
function MainPanel({ session, products, setProducts, members, setMembers, transactions, addTx, onLogout }) {
  const [view, setView] = useState("dashboard");
  const isAdmin = session.role === "admin";

  const nav = [
    { key: "dashboard", label: "Dashboard", icon: Icons.home, roles: ["admin", "empleado"] },
    { key: "socios", label: "Socios", icon: Icons.users, roles: ["admin", "empleado"] },
    { key: "venta", label: "Venta", icon: Icons.cart, roles: ["admin", "empleado"] },
    { key: "productos", label: "Productos", icon: Icons.box, roles: ["admin"] },
    { key: "movimientos", label: "Movimientos", icon: Icons.history, roles: ["admin"] },
    { key: "empleados", label: "Empleados", icon: Icons.staff, roles: ["admin"] },
  ].filter(n => n.roles.includes(session.role));

  return (
    <div style={S.appLayout}>
      <aside style={S.sidebar}>
        <div style={S.sidebarLogo}>🐍 <span>La Mamba Negra</span></div>
        <div style={S.sessionInfo}>
          <div style={{ fontSize: 11, color: "#64748b", textTransform: "uppercase", letterSpacing: 1 }}>{session.role}</div>
          <div style={{ color: "#e2e8f0", fontWeight: 600, fontSize: 13 }}>{session.name}</div>
        </div>
        <nav style={{ flex: 1, marginTop: 8 }}>
          {nav.map(n => (
            <button key={n.key} onClick={() => setView(n.key)} style={{ ...S.navBtn, ...(view === n.key ? S.navActive : {}) }}>
              <Icon d={n.icon} size={17} /> {n.label}
            </button>
          ))}
        </nav>
        <button onClick={onLogout} style={S.logoutBtn}><Icon d={Icons.logout} size={15} /> Cerrar sesión</button>
      </aside>

      <main style={S.main}>
        {view === "dashboard" && <Dashboard products={products} members={members} transactions={transactions} />}
        {view === "socios" && <SociosView members={members} setMembers={setMembers} transactions={transactions} addTx={addTx} isAdmin={isAdmin} />}
        {view === "venta" && <VentaView products={products} setProducts={setProducts} members={members} setMembers={setMembers} addTx={addTx} session={session} />}
        {view === "productos" && <ProductosView products={products} setProducts={setProducts} />}
        {view === "movimientos" && <MovimientosView transactions={transactions} members={members} />}
        {view === "empleados" && <EmpleadosView />}
      </main>
    </div>
  );
}

// ─── DASHBOARD ────────────────────────────────────────────────────────────────
function Dashboard({ products, members, transactions }) {
  const activos = members.filter(m => m.active).length;
  const totalStock = products.reduce((a, p) => a + p.stock, 0);
  const totalSaldo = members.reduce((a, m) => a + m.balance, 0);
  const ventasHoy = transactions.filter(t => t.type === "venta" && t.date?.startsWith(new Date().toLocaleDateString("es-ES"))).reduce((a, t) => a + t.amount, 0);
  const totalVentas = transactions.filter(t => t.type === "venta").reduce((a, t) => a + t.amount, 0);

  const stats = [
    { label: "Socios Activos", value: activos, icon: "👥", color: "#4ade80" },
    { label: "Stock Total", value: `${totalStock}g`, icon: "🌿", color: "#a78bfa" },
    { label: "Saldo Total Socios", value: `${totalSaldo.toFixed(2)}€`, icon: "💶", color: "#fbbf24" },
    { label: "Ventas Hoy", value: `${ventasHoy.toFixed(2)}€`, icon: "📈", color: "#60a5fa" },
    { label: "Ventas Totales", value: `${totalVentas.toFixed(2)}€`, icon: "💰", color: "#f87171" },
  ];

  return (
    <div>
      <h2 style={S.pageTitle}>Dashboard</h2>
      <div style={S.statsGrid}>
        {stats.map(s => (
          <div key={s.label} style={{ ...S.statCard, borderLeft: `4px solid ${s.color}` }}>
            <span style={{ fontSize: 30 }}>{s.icon}</span>
            <div>
              <div style={{ fontSize: 20, fontWeight: 700, color: "#e2e8f0" }}>{s.value}</div>
              <div style={{ fontSize: 11, color: "#64748b", textTransform: "uppercase", letterSpacing: 0.5 }}>{s.label}</div>
            </div>
          </div>
        ))}
      </div>
      <h3 style={S.sectionTitle}>Últimos movimientos</h3>
      <TxTable transactions={transactions.slice(0, 10)} members={members} />
    </div>
  );
}

// ─── SOCIOS ───────────────────────────────────────────────────────────────────
function SociosView({ members, setMembers, transactions, addTx, isAdmin }) {
  const [subview, setSubview] = useState("lista"); // lista | nuevo | ficha
  const [selected, setSelected] = useState(null);
  const [search, setSearch] = useState("");

  const filtered = members.filter(m =>
    m.name.toLowerCase().includes(search.toLowerCase()) ||
    m.dni.toLowerCase().includes(search.toLowerCase())
  );

  if (subview === "nuevo") return <NuevoSocio setMembers={setMembers} onBack={() => setSubview("lista")} />;
  if (subview === "ficha" && selected) return (
    <FichaSocio
      member={members.find(m => m.id === selected)}
      transactions={transactions.filter(t => t.memberId === selected)}
      setMembers={setMembers}
      addTx={addTx}
      isAdmin={isAdmin}
      onBack={() => setSubview("lista")}
    />
  );

  return (
    <div>
      <div style={S.pageHeader}>
        <h2 style={S.pageTitle}>Socios</h2>
        <button onClick={() => setSubview("nuevo")} style={S.btnPrimary}>
          <Icon d={Icons.plus} size={15} /> Registrar socio
        </button>
      </div>

      <div style={{ display: "flex", gap: 12, marginBottom: 20, alignItems: "center" }}>
        <input placeholder="Buscar por nombre o DNI..." value={search} onChange={e => setSearch(e.target.value)} style={{ ...S.input, flex: 1 }} />
        <span style={{ color: "#64748b", fontSize: 13 }}>{filtered.length} socios</span>
      </div>

      <div style={S.table}>
        <div style={{ ...S.tableHead, gridTemplateColumns: "2fr 1.2fr 1fr 1fr 0.8fr 0.6fr" }}>
          <span>Nombre</span><span>DNI</span><span>Alta</span><span>Saldo</span><span>Estado</span><span>Ver</span>
        </div>
        {filtered.length === 0 && <div style={{ padding: 24, color: "#475569", textAlign: "center" }}>No se encontraron socios</div>}
        {filtered.map(m => (
          <div key={m.id} style={{ ...S.tableRow, gridTemplateColumns: "2fr 1.2fr 1fr 1fr 0.8fr 0.6fr" }}>
            <span style={{ color: "#e2e8f0", fontWeight: 600 }}>{m.name}</span>
            <span style={{ color: "#94a3b8", fontFamily: "monospace", fontSize: 12 }}>{m.dni}</span>
            <span style={{ color: "#64748b", fontSize: 12 }}>{m.joinDate}</span>
            <span style={{ color: "#4ade80", fontWeight: 700 }}>{m.balance.toFixed(2)}€</span>
            <span>
              <span style={{ ...S.badge, background: m.active ? "#16532420" : "#7f1d1d20", color: m.active ? "#4ade80" : "#f87171", border: `1px solid ${m.active ? "#4ade8055" : "#f8717155"}` }}>
                {m.active ? "Activo" : "Baja"}
              </span>
            </span>
            <button onClick={() => { setSelected(m.id); setSubview("ficha"); }} style={S.iconBtn} title="Ver ficha">
              <Icon d={Icons.eye} size={15} />
            </button>
          </div>
        ))}
      </div>
    </div>
  );
}

function NuevoSocio({ setMembers, onBack }) {
  const [form, setForm] = useState({ name: "", dni: "", email: "", phone: "", notes: "" });
  const [error, setError] = useState("");
  const [ok, setOk] = useState(false);

  const handleSave = () => {
    if (!form.name.trim() || !form.dni.trim()) { setError("Nombre y DNI son obligatorios"); return; }
    const today = new Date().toLocaleDateString("es-ES");
    setMembers(prev => [...prev, { ...form, id: Date.now(), balance: 0, joinDate: today, active: true }]);
    setOk(true);
    setTimeout(() => { setOk(false); onBack(); }, 1500);
  };

  return (
    <div>
      <div style={S.pageHeader}>
        <h2 style={S.pageTitle}>Registrar nuevo socio</h2>
        <button onClick={onBack} style={S.btnSecondary}>← Volver</button>
      </div>
      <div style={S.formCard}>
        {ok && <div style={S.successBanner}>✅ Socio registrado correctamente</div>}
        {error && <div style={S.errorBox}>{error}</div>}
        <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 16 }}>
          <div>
            <label style={S.label}>Nombre completo *</label>
            <input value={form.name} onChange={e => setForm({ ...form, name: e.target.value })} style={S.input} placeholder="Nombre y apellidos" />
          </div>
          <div>
            <label style={S.label}>DNI / NIE *</label>
            <input value={form.dni} onChange={e => setForm({ ...form, dni: e.target.value.toUpperCase() })} style={S.input} placeholder="12345678A" />
          </div>
          <div>
            <label style={S.label}>Email</label>
            <input value={form.email} onChange={e => setForm({ ...form, email: e.target.value })} style={S.input} placeholder="correo@ejemplo.com" />
          </div>
          <div>
            <label style={S.label}>Teléfono</label>
            <input value={form.phone} onChange={e => setForm({ ...form, phone: e.target.value })} style={S.input} placeholder="612345678" />
          </div>
        </div>
        <div style={{ marginTop: 16 }}>
          <label style={S.label}>Notas / Observaciones</label>
          <textarea value={form.notes} onChange={e => setForm({ ...form, notes: e.target.value })} style={{ ...S.input, width: "100%", minHeight: 80, resize: "vertical", boxSizing: "border-box" }} placeholder="Información adicional..." />
        </div>
        <div style={{ display: "flex", gap: 10, marginTop: 20 }}>
          <button onClick={handleSave} style={S.btnPrimary}>💾 Guardar socio</button>
          <button onClick={onBack} style={S.btnSecondary}>Cancelar</button>
        </div>
      </div>
    </div>
  );
}

function FichaSocio({ member, transactions, setMembers, addTx, isAdmin, onBack }) {
  const [depositModal, setDepositModal] = useState(false);
  const [depositAmt, setDepositAmt] = useState("");
  const [editMode, setEditMode] = useState(false);
  const [form, setForm] = useState({ ...member });

  if (!member) return null;

  const doDeposit = () => {
    const amt = parseFloat(depositAmt);
    if (!amt || amt <= 0) return;
    setMembers(prev => prev.map(m => m.id === member.id ? { ...m, balance: m.balance + amt } : m));
    addTx({ type: "recarga", memberId: member.id, amount: amt, desc: `Recarga saldo — ${member.name}`, staff: "—" });
    setDepositModal(false);
    setDepositAmt("");
  };

  const toggleActive = () => setMembers(prev => prev.map(m => m.id === member.id ? { ...m, active: !m.active } : m));

  const saveEdit = () => {
    setMembers(prev => prev.map(m => m.id === member.id ? { ...m, ...form } : m));
    setEditMode(false);
  };

  return (
    <div>
      <div style={S.pageHeader}>
        <h2 style={S.pageTitle}>Ficha de Socio</h2>
        <button onClick={onBack} style={S.btnSecondary}>← Volver</button>
      </div>

      <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 20, marginBottom: 20 }}>
        {/* Datos personales */}
        <div style={S.formCard}>
          <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 16 }}>
            <h3 style={{ color: "#e2e8f0", margin: 0, fontSize: 15 }}>📋 Datos personales</h3>
            {isAdmin && <button onClick={() => setEditMode(!editMode)} style={S.iconBtn}><Icon d={Icons.edit} size={14} /></button>}
          </div>
          {editMode ? (
            <div style={{ display: "flex", flexDirection: "column", gap: 10 }}>
              <div><label style={S.label}>Nombre</label><input value={form.name} onChange={e => setForm({ ...form, name: e.target.value })} style={S.input} /></div>
              <div><label style={S.label}>DNI</label><input value={form.dni} onChange={e => setForm({ ...form, dni: e.target.value })} style={S.input} /></div>
              <div><label style={S.label}>Email</label><input value={form.email} onChange={e => setForm({ ...form, email: e.target.value })} style={S.input} /></div>
              <div><label style={S.label}>Teléfono</label><input value={form.phone} onChange={e => setForm({ ...form, phone: e.target.value })} style={S.input} /></div>
              <div><label style={S.label}>Notas</label><textarea value={form.notes} onChange={e => setForm({ ...form, notes: e.target.value })} style={{ ...S.input, minHeight: 60, resize: "vertical" }} /></div>
              <div style={{ display: "flex", gap: 8, marginTop: 4 }}>
                <button onClick={saveEdit} style={S.btnPrimary}>Guardar</button>
                <button onClick={() => setEditMode(false)} style={S.btnSecondary}>Cancelar</button>
              </div>
            </div>
          ) : (
            <div style={{ display: "flex", flexDirection: "column", gap: 10 }}>
              {[
                ["Nombre", member.name],
                ["DNI / NIE", member.dni],
                ["Email", member.email || "—"],
                ["Teléfono", member.phone || "—"],
                ["Fecha de alta", member.joinDate],
                ["Notas", member.notes || "—"],
              ].map(([k, v]) => (
                <div key={k} style={{ display: "flex", justifyContent: "space-between", borderBottom: "1px solid #1a2e1a", paddingBottom: 8 }}>
                  <span style={{ color: "#64748b", fontSize: 12 }}>{k}</span>
                  <span style={{ color: "#e2e8f0", fontSize: 13, textAlign: "right", maxWidth: "60%" }}>{v}</span>
                </div>
              ))}
            </div>
          )}
        </div>

        {/* Cuenta y acciones */}
        <div style={{ display: "flex", flexDirection: "column", gap: 16 }}>
          <div style={S.formCard}>
            <h3 style={{ color: "#e2e8f0", margin: "0 0 16px", fontSize: 15 }}>💶 Cuenta</h3>
            <div style={{ textAlign: "center", padding: "12px 0" }}>
              <div style={{ fontSize: 36, fontWeight: 700, color: "#4ade80" }}>{member.balance.toFixed(2)}€</div>
              <div style={{ color: "#64748b", fontSize: 12, marginTop: 4 }}>Saldo disponible</div>
            </div>
            <button onClick={() => setDepositModal(true)} style={{ ...S.btnPrimary, width: "100%", marginTop: 8 }}>
              💶 Recargar saldo
            </button>
          </div>

          <div style={S.formCard}>
            <h3 style={{ color: "#e2e8f0", margin: "0 0 16px", fontSize: 15 }}>⚙️ Estado del socio</h3>
            <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between" }}>
              <span style={{ color: "#94a3b8", fontSize: 13 }}>Estado actual:</span>
              <span style={{ ...S.badge, background: member.active ? "#16532420" : "#7f1d1d20", color: member.active ? "#4ade80" : "#f87171", border: `1px solid ${member.active ? "#4ade8055" : "#f8717155"}` }}>
                {member.active ? "Activo" : "Baja"}
              </span>
            </div>
            {isAdmin && (
              <button onClick={toggleActive} style={{ ...S.btnSecondary, width: "100%", marginTop: 12, color: member.active ? "#f87171" : "#4ade80", borderColor: member.active ? "#f8717155" : "#4ade8055" }}>
                {member.active ? "🔴 Dar de baja" : "🟢 Reactivar socio"}
              </button>
            )}
          </div>
        </div>
      </div>

      {/* Historial del socio */}
      <h3 style={S.sectionTitle}>Historial de movimientos</h3>
      <TxTable transactions={transactions} members={[member]} showMember={false} />

      {depositModal && (
        <Modal title={`Recargar saldo — ${member.name}`} onClose={() => setDepositModal(false)}>
          <p style={{ color: "#94a3b8", marginBottom: 12 }}>Saldo actual: <strong style={{ color: "#4ade80" }}>{member.balance.toFixed(2)}€</strong></p>
          <label style={S.label}>Importe a recargar (€)</label>
          <input type="number" min="1" step="0.5" placeholder="0.00" value={depositAmt} onChange={e => setDepositAmt(e.target.value)} style={{ ...S.input, width: "100%", boxSizing: "border-box" }} />
          <div style={{ display: "flex", gap: 8, marginTop: 14 }}>
            <button onClick={doDeposit} style={S.btnPrimary}>Confirmar recarga</button>
            <button onClick={() => setDepositModal(false)} style={S.btnSecondary}>Cancelar</button>
          </div>
        </Modal>
      )}
    </div>
  );
}

// ─── VENTA ────────────────────────────────────────────────────────────────────
function VentaView({ products, setProducts, members, setMembers, addTx, session }) {
  const [memberSearch, setMemberSearch] = useState("");
  const [selectedMember, setSelectedMember] = useState(null);
  const [cart, setCart] = useState([]);
  const [qty, setQty] = useState({});
  const [done, setDone] = useState(false);

  const member = members.find(m => m.id === selectedMember);
  const cartTotal = cart.reduce((a, c) => a + c.price * c.qty, 0);

  const filteredMembers = memberSearch.length > 1
    ? members.filter(m => m.active && (m.name.toLowerCase().includes(memberSearch.toLowerCase()) || m.dni.toLowerCase().includes(memberSearch.toLowerCase())))
    : [];

  const addToCart = (p) => {
    const q = parseFloat(qty[p.id] || 1);
    if (!q || q <= 0 || q > p.stock) return;
    setCart(prev => {
      const ex = prev.find(c => c.id === p.id);
      if (ex) return prev.map(c => c.id === p.id ? { ...c, qty: +(c.qty + q).toFixed(2) } : c);
      return [...prev, { ...p, qty: q }];
    });
    setQty(prev => ({ ...prev, [p.id]: "" }));
  };

  const checkout = () => {
    if (!member || cartTotal > member.balance || cart.length === 0) return;
    setMembers(prev => prev.map(m => m.id === member.id ? { ...m, balance: +(m.balance - cartTotal).toFixed(2) } : m));
    setProducts(prev => prev.map(p => { const c = cart.find(c => c.id === p.id); return c ? { ...p, stock: +(p.stock - c.qty).toFixed(2) } : p; }));
    cart.forEach(c => addTx({ type: "venta", memberId: member.id, amount: +(c.price * c.qty).toFixed(2), desc: `${c.qty}g ${c.name}`, staff: session.name }));
    setCart([]);
    setSelectedMember(null);
    setMemberSearch("");
    setDone(true);
    setTimeout(() => setDone(false), 3000);
  };

  return (
    <div>
      <h2 style={S.pageTitle}>Punto de Venta</h2>
      {done && <div style={S.successBanner}>✅ Venta completada con éxito</div>}

      {/* Selección de socio */}
      <div style={S.formCard}>
        <h3 style={{ color: "#e2e8f0", margin: "0 0 12px", fontSize: 15 }}>👤 Seleccionar socio</h3>
        {member ? (
          <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center" }}>
            <div>
              <div style={{ color: "#e2e8f0", fontWeight: 700 }}>{member.name}</div>
              <div style={{ color: "#64748b", fontSize: 12 }}>{member.dni}</div>
              <div style={{ color: "#4ade80", fontWeight: 700, marginTop: 4 }}>Saldo: {member.balance.toFixed(2)}€</div>
            </div>
            <button onClick={() => { setSelectedMember(null); setMemberSearch(""); setCart([]); }} style={S.btnSecondary}>Cambiar</button>
          </div>
        ) : (
          <div style={{ position: "relative" }}>
            <input placeholder="Buscar socio por nombre o DNI..." value={memberSearch} onChange={e => setMemberSearch(e.target.value)} style={{ ...S.input, width: "100%", boxSizing: "border-box" }} />
            {filteredMembers.length > 0 && (
              <div style={S.dropdown}>
                {filteredMembers.map(m => (
                  <div key={m.id} onClick={() => { setSelectedMember(m.id); setMemberSearch(""); }} style={S.dropdownItem}>
                    <span style={{ color: "#e2e8f0" }}>{m.name}</span>
                    <span style={{ color: "#64748b", fontSize: 12 }}>{m.dni} · <span style={{ color: "#4ade80" }}>{m.balance.toFixed(2)}€</span></span>
                  </div>
                ))}
              </div>
            )}
          </div>
        )}
      </div>

      <div style={{ display: "grid", gridTemplateColumns: "1fr 340px", gap: 20, marginTop: 0 }}>
        {/* Productos */}
        <div>
          <h3 style={S.sectionTitle}>Catálogo</h3>
          <div style={S.productGrid}>
            {products.filter(p => p.stock > 0).map(p => (
              <div key={p.id} style={S.productCard}>
                <div style={{ fontSize: 30 }}>{p.img}</div>
                <div style={{ fontWeight: 700, color: "#e2e8f0", fontSize: 14, marginTop: 6 }}>{p.name}</div>
                <div style={{ color: "#64748b", fontSize: 11 }}>{p.category}{p.thc ? ` · ${p.thc}` : ""}</div>
                <div style={{ display: "flex", justifyContent: "space-between", marginTop: 8, marginBottom: 10 }}>
                  <span style={{ color: "#4ade80", fontWeight: 700 }}>{p.price}€/g</span>
                  <span style={{ color: "#60a5fa", fontSize: 11 }}>Stock: {p.stock}g</span>
                </div>
                <div style={{ display: "flex", gap: 6 }}>
                  <input type="number" min="0.1" step="0.1" placeholder="g" value={qty[p.id] || ""} onChange={e => setQty(prev => ({ ...prev, [p.id]: e.target.value }))} style={{ ...S.input, flex: 1, padding: "7px 8px", fontSize: 13 }} />
                  <button onClick={() => addToCart(p)} style={{ ...S.btnPrimary, padding: "7px 12px", fontSize: 13 }} disabled={!selectedMember}>+</button>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Carrito */}
        <div>
          <h3 style={S.sectionTitle}>Carrito</h3>
          <div style={{ ...S.formCard, padding: 16 }}>
            {cart.length === 0
              ? <div style={{ color: "#475569", textAlign: "center", padding: "20px 0", fontSize: 13 }}>Sin productos</div>
              : cart.map(c => (
                <div key={c.id} style={{ display: "flex", justifyContent: "space-between", alignItems: "center", padding: "8px 0", borderBottom: "1px solid #1a2e1a" }}>
                  <div>
                    <div style={{ color: "#e2e8f0", fontSize: 13 }}>{c.img} {c.name}</div>
                    <div style={{ color: "#64748b", fontSize: 11 }}>{c.qty}g × {c.price}€</div>
                  </div>
                  <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
                    <span style={{ color: "#4ade80", fontWeight: 700 }}>{(c.price * c.qty).toFixed(2)}€</span>
                    <button onClick={() => setCart(prev => prev.filter(x => x.id !== c.id))} style={{ ...S.iconBtn, padding: "4px 7px", fontSize: 12 }}>✕</button>
                  </div>
                </div>
              ))
            }
            {cart.length > 0 && (
              <div style={{ marginTop: 14 }}>
                <div style={{ display: "flex", justifyContent: "space-between", marginBottom: 6 }}>
                  <span style={{ color: "#94a3b8" }}>Total:</span>
                  <span style={{ color: "#4ade80", fontWeight: 700, fontSize: 18 }}>{cartTotal.toFixed(2)}€</span>
                </div>
                {member && (
                  <div style={{ display: "flex", justifyContent: "space-between", marginBottom: 12 }}>
                    <span style={{ color: "#94a3b8", fontSize: 12 }}>Saldo socio:</span>
                    <span style={{ color: member.balance >= cartTotal ? "#4ade80" : "#f87171", fontSize: 12, fontWeight: 600 }}>{member.balance.toFixed(2)}€</span>
                  </div>
                )}
                {!selectedMember && <p style={{ color: "#fbbf24", fontSize: 11, marginBottom: 8 }}>⚠ Selecciona un socio para cobrar</p>}
                {member && member.balance < cartTotal && <p style={{ color: "#f87171", fontSize: 11, marginBottom: 8 }}>⚠ Saldo insuficiente</p>}
                <button onClick={checkout} disabled={!member || cartTotal > member?.balance} style={{ ...S.btnPrimary, width: "100%", opacity: (!member || cartTotal > member?.balance) ? 0.4 : 1 }}>
                  ✅ Cobrar
                </button>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}

// ─── PRODUCTOS ────────────────────────────────────────────────────────────────
function ProductosView({ products, setProducts }) {
  const [showForm, setShowForm] = useState(false);
  const [form, setForm] = useState({ name: "", category: "Flor", price: "", stock: "", thc: "", img: "🌿" });
  const emojis = ["🌿", "🌱", "🍃", "🟫", "🟤", "⚗️", "💨", "🫙", "🐍"];

  const addProduct = () => {
    if (!form.name || !form.price || !form.stock) return;
    setProducts(prev => [...prev, { ...form, id: Date.now(), price: parseFloat(form.price), stock: parseFloat(form.stock) }]);
    setForm({ name: "", category: "Flor", price: "", stock: "", thc: "", img: "🌿" });
    setShowForm(false);
  };

  return (
    <div>
      <div style={S.pageHeader}>
        <h2 style={S.pageTitle}>Productos</h2>
        <button onClick={() => setShowForm(!showForm)} style={S.btnPrimary}><Icon d={Icons.plus} size={15} /> Añadir producto</button>
      </div>
      {showForm && (
        <div style={S.formCard}>
          <h3 style={{ color: "#e2e8f0", margin: "0 0 16px", fontSize: 15 }}>Nuevo producto</h3>
          <div style={{ display: "grid", gridTemplateColumns: "2fr 1fr 1fr 1fr 1fr", gap: 12 }}>
            <div><label style={S.label}>Nombre *</label><input value={form.name} onChange={e => setForm({ ...form, name: e.target.value })} style={S.input} /></div>
            <div><label style={S.label}>Categoría</label>
              <select value={form.category} onChange={e => setForm({ ...form, category: e.target.value })} style={S.input}>
                {["Flor", "Hash", "Aceite", "Comestible", "Otro"].map(c => <option key={c}>{c}</option>)}
              </select>
            </div>
            <div><label style={S.label}>Precio €/g *</label><input type="number" value={form.price} onChange={e => setForm({ ...form, price: e.target.value })} style={S.input} /></div>
            <div><label style={S.label}>Stock (g) *</label><input type="number" value={form.stock} onChange={e => setForm({ ...form, stock: e.target.value })} style={S.input} /></div>
            <div><label style={S.label}>THC %</label><input value={form.thc} onChange={e => setForm({ ...form, thc: e.target.value })} style={S.input} placeholder="22%" /></div>
          </div>
          <div style={{ display: "flex", gap: 6, marginTop: 12, flexWrap: "wrap" }}>
            {emojis.map(e => <button key={e} onClick={() => setForm({ ...form, img: e })} style={{ ...S.iconBtn, background: form.img === e ? "#4ade8022" : "transparent", border: `1px solid ${form.img === e ? "#4ade80" : "#334155"}` }}>{e}</button>)}
          </div>
          <div style={{ display: "flex", gap: 8, marginTop: 14 }}>
            <button onClick={addProduct} style={S.btnPrimary}>Guardar</button>
            <button onClick={() => setShowForm(false)} style={S.btnSecondary}>Cancelar</button>
          </div>
        </div>
      )}
      <div style={S.productGrid}>
        {products.map(p => (
          <div key={p.id} style={S.productCard}>
            <div style={{ fontSize: 34 }}>{p.img}</div>
            <div style={{ fontWeight: 700, color: "#e2e8f0", fontSize: 15, marginTop: 8 }}>{p.name}</div>
            <div style={{ color: "#64748b", fontSize: 11, marginBottom: 10 }}>{p.category}{p.thc ? ` · THC ${p.thc}` : ""}</div>
            <div style={{ display: "flex", justifyContent: "space-between", marginBottom: 12 }}>
              <span style={{ color: "#4ade80", fontWeight: 700 }}>{p.price}€/g</span>
              <span style={{ color: "#60a5fa", fontSize: 12 }}>Stock: {p.stock}g</span>
            </div>
            <button onClick={() => setProducts(prev => prev.filter(x => x.id !== p.id))} style={{ ...S.btnDanger, width: "100%" }}>
              <Icon d={Icons.trash} size={13} /> Eliminar
            </button>
          </div>
        ))}
      </div>
    </div>
  );
}

// ─── MOVIMIENTOS ──────────────────────────────────────────────────────────────
function MovimientosView({ transactions, members }) {
  const [filter, setFilter] = useState("todos");
  const filtered = filter === "todos" ? transactions : transactions.filter(t => t.type === filter);
  return (
    <div>
      <div style={S.pageHeader}>
        <h2 style={S.pageTitle}>Movimientos</h2>
        <div style={{ display: "flex", gap: 6 }}>
          {["todos", "venta", "recarga"].map(f => (
            <button key={f} onClick={() => setFilter(f)} style={{ ...S.btnSecondary, padding: "8px 14px", fontSize: 12, background: filter === f ? "#1a3a1a" : undefined, color: filter === f ? "#4ade80" : undefined }}>
              {f.charAt(0).toUpperCase() + f.slice(1)}
            </button>
          ))}
        </div>
      </div>
      <TxTable transactions={filtered} members={members} />
    </div>
  );
}

// ─── EMPLEADOS ────────────────────────────────────────────────────────────────
function EmpleadosView() {
  return (
    <div>
      <h2 style={S.pageTitle}>Empleados</h2>
      <div style={S.formCard}>
        <h3 style={{ color: "#e2e8f0", margin: "0 0 16px", fontSize: 15 }}>👥 Personal con acceso</h3>
        <div style={S.table}>
          <div style={{ ...S.tableHead, gridTemplateColumns: "1fr 1fr 1fr" }}>
            <span>Usuario</span><span>Nombre</span><span>Rol</span>
          </div>
          {USERS.map(u => (
            <div key={u.id} style={{ ...S.tableRow, gridTemplateColumns: "1fr 1fr 1fr" }}>
              <span style={{ color: "#94a3b8", fontFamily: "monospace" }}>{u.user}</span>
              <span style={{ color: "#e2e8f0" }}>{u.name}</span>
              <span>
                <span style={{ ...S.badge, background: u.role === "admin" ? "#1e3a8a22" : "#16532422", color: u.role === "admin" ? "#60a5fa" : "#4ade80", border: `1px solid ${u.role === "admin" ? "#60a5fa55" : "#4ade8055"}` }}>
                  {u.role}
                </span>
              </span>
            </div>
          ))}
        </div>
        <p style={{ color: "#475569", fontSize: 12, marginTop: 16 }}>💡 Para añadir o eliminar empleados, edita las credenciales directamente en el código fuente.</p>
      </div>
    </div>
  );
}

// ─── TX TABLE ────────────────────────────────────────────────────────────────
function TxTable({ transactions, members, showMember = true }) {
  const getName = (id) => members.find(m => m.id === id)?.name || "—";
  const cols = showMember ? "1fr 2fr 2fr 1fr 1fr" : "1fr 2fr 1fr 1fr";
  return (
    <div style={S.table}>
      <div style={{ ...S.tableHead, gridTemplateColumns: cols }}>
        <span>Tipo</span>
        {showMember && <span>Socio</span>}
        <span>Descripción</span>
        <span>Importe</span>
        <span>Fecha</span>
      </div>
      {transactions.length === 0 && <div style={{ padding: 24, color: "#475569", textAlign: "center" }}>Sin movimientos</div>}
      {transactions.map(t => (
        <div key={t.id} style={{ ...S.tableRow, gridTemplateColumns: cols }}>
          <span style={{ color: t.type === "recarga" ? "#4ade80" : "#f87171", fontWeight: 600, fontSize: 12 }}>
            {t.type === "recarga" ? "⬆ Recarga" : "⬇ Venta"}
          </span>
          {showMember && <span style={{ color: "#cbd5e1", fontSize: 13 }}>{getName(t.memberId)}</span>}
          <span style={{ color: "#94a3b8", fontSize: 12 }}>{t.desc}</span>
          <span style={{ color: t.type === "recarga" ? "#4ade80" : "#f87171", fontWeight: 600 }}>
            {t.type === "recarga" ? "+" : "-"}{t.amount.toFixed(2)}€
          </span>
          <span style={{ color: "#475569", fontSize: 11 }}>{t.date}</span>
        </div>
      ))}
    </div>
  );
}

// ─── MODAL ───────────────────────────────────────────────────────────────────
function Modal({ title, children, onClose }) {
  return (
    <div style={S.overlay}>
      <div style={S.modal}>
        <div style={S.modalHeader}>
          <h3 style={{ color: "#e2e8f0", margin: 0, fontSize: 16 }}>{title}</h3>
          <button onClick={onClose} style={{ background: "none", border: "none", color: "#94a3b8", fontSize: 20, cursor: "pointer" }}>✕</button>
        </div>
        {children}
      </div>
    </div>
  );
}

// ─── ESTILOS ─────────────────────────────────────────────────────────────────
const S = {
  loginBg: { minHeight: "100vh", display: "flex", alignItems: "center", justifyContent: "center", background: "linear-gradient(135deg, #0a0a0a 0%, #0f1a0a 50%, #0a0a0a 100%)", fontFamily: "'Georgia', serif" },
  loginCard: { background: "#0d1117", border: "1px solid #1a2e1a", borderRadius: 16, padding: 44, width: "100%", maxWidth: 400, boxShadow: "0 0 80px #00000088, 0 0 40px #4ade8008" },
  loginLogo: { textAlign: "center", marginBottom: 32 },
  loginTitle: { color: "#e2e8f0", margin: "10px 0 6px", fontSize: 26, fontWeight: 700, letterSpacing: 3 },
  loginSub: { color: "#475569", fontSize: 11, letterSpacing: 2, textTransform: "uppercase", margin: 0 },
  formGroup: { display: "flex", flexDirection: "column", gap: 12 },
  input: { background: "#070d07", border: "1px solid #1e3a2a", borderRadius: 8, padding: "11px 14px", color: "#e2e8f0", fontSize: 14, outline: "none", fontFamily: "inherit", width: "100%", boxSizing: "border-box" },
  label: { display: "block", color: "#64748b", fontSize: 11, textTransform: "uppercase", letterSpacing: 0.8, marginBottom: 5 },
  errorBox: { background: "#7f1d1d22", border: "1px solid #f8717166", borderRadius: 8, padding: "10px 14px", color: "#f87171", fontSize: 13, marginBottom: 14 },
  successBanner: { background: "#16532422", border: "1px solid #4ade8066", borderRadius: 8, padding: "12px 16px", color: "#4ade80", fontWeight: 600, marginBottom: 18 },
  btnPrimary: { background: "linear-gradient(135deg, #14532d, #166534)", border: "1px solid #4ade8033", color: "#fff", padding: "11px 18px", borderRadius: 8, cursor: "pointer", fontFamily: "inherit", fontSize: 13, fontWeight: 600, display: "flex", alignItems: "center", gap: 6, justifyContent: "center" },
  btnSecondary: { background: "#111827", border: "1px solid #1e293b", color: "#94a3b8", padding: "11px 18px", borderRadius: 8, cursor: "pointer", fontFamily: "inherit", fontSize: 13 },
  btnDanger: { background: "#7f1d1d22", border: "1px solid #f8717144", color: "#f87171", padding: "8px 14px", borderRadius: 6, cursor: "pointer", fontFamily: "inherit", fontSize: 12, display: "flex", alignItems: "center", gap: 4, justifyContent: "center" },
  iconBtn: { background: "#1e293b", border: "1px solid #334155", color: "#94a3b8", padding: "7px 11px", borderRadius: 6, cursor: "pointer", fontSize: 13, display: "flex", alignItems: "center" },
  appLayout: { display: "flex", minHeight: "100vh", background: "#0a0a0a", fontFamily: "'Georgia', serif" },
  sidebar: { width: 215, background: "#070d07", borderRight: "1px solid #1a2e1a", display: "flex", flexDirection: "column", padding: "0 0 16px", position: "sticky", top: 0, height: "100vh" },
  sidebarLogo: { color: "#4ade80", fontWeight: 700, fontSize: 16, padding: "20px 20px 16px", borderBottom: "1px solid #1a2e1a", display: "flex", alignItems: "center", gap: 8, letterSpacing: 1 },
  sessionInfo: { padding: "12px 20px 8px", borderBottom: "1px solid #1a2e1a" },
  navBtn: { display: "flex", alignItems: "center", gap: 9, padding: "10px 16px", margin: "2px 8px", borderRadius: 7, background: "none", border: "none", color: "#64748b", cursor: "pointer", fontFamily: "inherit", fontSize: 13, width: "calc(100% - 16px)", textAlign: "left" },
  navActive: { background: "#1a3a1a", color: "#4ade80" },
  logoutBtn: { display: "flex", alignItems: "center", gap: 7, padding: "10px 16px", margin: "8px", borderRadius: 7, background: "none", border: "1px solid #1e293b", color: "#475569", cursor: "pointer", fontFamily: "inherit", fontSize: 12 },
  main: { flex: 1, padding: "28px 32px", overflowY: "auto", maxHeight: "100vh" },
  pageTitle: { color: "#e2e8f0", fontSize: 20, fontWeight: 700, margin: "0 0 22px" },
  pageHeader: { display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 20 },
  sectionTitle: { color: "#475569", fontSize: 11, textTransform: "uppercase", letterSpacing: 1.5, margin: "24px 0 10px" },
  statsGrid: { display: "grid", gridTemplateColumns: "repeat(auto-fill, minmax(185px, 1fr))", gap: 14 },
  statCard: { background: "#0d1117", borderRadius: 10, padding: "18px 20px", display: "flex", alignItems: "center", gap: 14, border: "1px solid #1a2e1a" },
  formCard: { background: "#0d1117", border: "1px solid #1a2e1a", borderRadius: 12, padding: 22, marginBottom: 20 },
  table: { background: "#0d1117", borderRadius: 10, overflow: "hidden", border: "1px solid #1a2e1a" },
  tableHead: { display: "grid", gridTemplateColumns: "repeat(4,1fr)", padding: "11px 18px", background: "#070d07", color: "#4ade80", fontSize: 10, textTransform: "uppercase", letterSpacing: 1.2, gap: 8 },
  tableRow: { display: "grid", gridTemplateColumns: "repeat(4,1fr)", padding: "13px 18px", borderTop: "1px solid #111f11", fontSize: 13, gap: 8, alignItems: "center" },
  badge: { padding: "3px 10px", borderRadius: 20, fontSize: 11, fontWeight: 600, display: "inline-block" },
  productGrid: { display: "grid", gridTemplateColumns: "repeat(auto-fill, minmax(170px, 1fr))", gap: 14 },
  productCard: { background: "#0d1117", border: "1px solid #1a2e1a", borderRadius: 10, padding: 16, display: "flex", flexDirection: "column" },
  dropdown: { position: "absolute", top: "100%", left: 0, right: 0, background: "#0d1117", border: "1px solid #1a2e1a", borderRadius: 8, zIndex: 100, maxHeight: 220, overflowY: "auto", marginTop: 4 },
  dropdownItem: { padding: "12px 16px", cursor: "pointer", display: "flex", justifyContent: "space-between", alignItems: "center", borderBottom: "1px solid #111f11" },
  overlay: { position: "fixed", inset: 0, background: "#000000aa", display: "flex", alignItems: "center", justifyContent: "center", zIndex: 1000 },
  modal: { background: "#0d1117", border: "1px solid #1a2e1a", borderRadius: 14, padding: 26, width: "100%", maxWidth: 420 },
  modalHeader: { display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 18 },
};
